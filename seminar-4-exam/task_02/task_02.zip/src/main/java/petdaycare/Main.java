package petdaycare;

import petdaycare.Dragon;
import petdaycare.NinjaCat;
import petdaycare.Unicorn;

/**
 * Use this class to run some checks on your own code
 */
public class Main {
    public static void main(String[] args) {
        // Write your code here
        
    }
}
